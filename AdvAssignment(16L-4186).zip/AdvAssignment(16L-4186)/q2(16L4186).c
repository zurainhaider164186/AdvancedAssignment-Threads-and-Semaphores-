#include<string.h>
#include <pthread.h> 
#include <semaphore.h> 
#include <sys/ioctl.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/ipc.h>
#include <sys/sem.h>
#include <stdio.h>
#include <unistd.h>
#include <semaphore.h> 
#include <sys/shm.h>
#include <time.h>
#include <stdlib.h>
const key_t shm_key =6;
sem_t sema;
struct buf
{
char buf2[50];
char buf1[50];
sem_t p;
sem_t p1;
};
int main() 
{ 
    	int id = shmget(shm_key,sizeof(struct buf),0600|IPC_CREAT|IPC_EXCL);
    	if(id < 0)
        {
    	return 1;
        }			
	sem_init(&sema,0,1);
	FILE *fp ; 
	int pid;
        int pid1;
        int pid2;
        int pid3; 
	pid = fork(); 
	if (pid == 0) 
        {
        char data[20]; 
        fp=fopen("file1.txt","r") ;   
        if (fp==NULL) 
	 { 
	    printf("file1.txt has failed to open.") ; 
         } 
        else
         { 
	   while(fgets(data,20,fp)!=NULL) 
	      {
		  printf("Contents of file1 are:");
		  printf("%s",data); 	  
	      } 
	fclose(fp); 		   
        } 	    
	sem_wait(&sema); 
	printf("Process 1 writing\n"); 	
	void* memory = shmat(id, NULL ,0);	
      	struct buf* read = (struct buf*) memory;
	strncpy(read->buf1,data,15);
	read->buf1[10]='\0';		
	sem_post(&sema); 
	shmdt(memory); 		
        }
	else 
	{ 
	 pid1 = fork(); 
	 if (pid1 == 0)  
	 { 
	   sleep(2); 		 	
	   char data[20]; 		  
	   fp=fopen("file2.txt","r"); 		      
	   if(fp==NULL) 
	   { 
	    printf("file.txt file failed to open!!") ; 
	   } 
	 else
	 { 			 
             while(fgets(data,20,fp)!=NULL) 
               { 
	          printf("Contents of file2 are:");
		  printf("%s",data); 			   
	       }
	    fclose(fp); 
	 }			    		    
	sem_wait(&sema); 
	printf("Process 2 writing first\n"); 			
	void* memory = shmat(id, NULL ,0);
      	struct buf* read = (struct buf*) memory;
	strncat(read->buf1,data,15);
	read->buf1[20]='\0'; 
	sem_post(&sema); 
	shmdt(memory); 				
	} 
	else 
	{ 
	    pid2 = fork(); 
	    if (pid2 == 0)  
              { 	
		sleep(3);  					
		sem_wait(&sema); 
		printf("Process 3 reading process\n"); 		
		void* memory=shmat(id,NULL,0);
      		struct buf*read=(struct buf*)memory;
		strcat(read->buf2,read->buf1); 
		sem_post(&sema); 
		shmdt(memory); 		
	      } 	
	    else 
	      { 
		pid3=fork();		
		if(pid3==0) 
		{
		 sleep(4); 				
		 sem_wait(&sema); 
		 printf("Process 4 Reading and Displaying \n"); 
		 void* memory=shmat(id,NULL,0);
      		 struct buf*read =(struct buf*)memory;
		 printf("%s",read->buf2);
		 sem_post(&sema); 
		 shmdt(memory); 		
		 shmctl(id,IPC_RMID,NULL);			
		}			
		else
		{
                 sleep(5);						 	
		}
	} 
      } 
    } 
return 0; 
} 


