#include<pthread.h>     //headerfiles
#include<stdio.h>
#include <time.h>
#include <semaphore.h> 
#include<stdlib.h>
#include<string.h>
#include <unistd.h>
int last=1;
int present=1;         //Global Variables
int potpatient=1;
sem_t mutex11;
sem_t coronapat;      //semaphores required
sem_t flupat;
int rg()
{
	int rnum=rand() % 2;    
	return rnum;
}
void coronatester()
{
   int rand=rg();
   if (rand==0)
   { 
   	sem_post(&flupat);
   	potpatient--;

   }
   else
   {
      sem_post(&coronapat);
      potpatient--; 
   }
}
void coronapattest()
{	 
		int rand=rg();
		last=present;
		present=rand;
		if (present==0 && last == 0)
		{
			sem_wait(&coronapat);
		}
}
void * pat()
{
	potpatient++;   
        pthread_exit(NULL);
}
int main(int argc, char const *argv[])
{
        pthread_t pid;
	int num;
        sem_init(&flupat,0,0);
	sem_init(&coronapat,0,0);
        sem_init(&mutex11, 0, 1);
	printf("Please Enter the number of Threads:");
	scanf("%d",&num);
	printf("Your Entered number is %d \n",num);
	for(int i=0;i<num;i++)
	{
          pthread_create(&pid,NULL,&pat,NULL);   
	}
        printf("Patient counts are %d\n",potpatient);
        for (int i = 0; i < potpatient; i++)
        {
    	coronatester();
        }
        int val11;
        while (val11>0)
        {
    	  coronapattest();
    	  val11--;
        }
	return 0;
}
	
	
	

